// "use client";

// import React from 'react'
// import { AppKitButton } from "@reown/appkit";
// // import { useConnect } from 'wagmi';
// // import { injected } from 'wagmi/connectors';

// const ConnectButton = () => {
//   // const { connect } = useConnect();

//   return <AppKitButton />
  
// //   return (
// //     <button
// //       className='px-2 py-1 bg-white text-black font-semibold rounded-full h-fit w-[100px] justify-center my-auto md:text-[16px] text-xm flex cursor-pointer justify-self-end capitalize'
// //       onClick={() => connect({ connector: injected() })}
// //     >
// //       Connect
// //     </button>
// //   )
// }

// export default ConnectButton