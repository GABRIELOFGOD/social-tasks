// import { IDashboardSideBar } from "@/model/DashboardTypes";
// import { MdSpaceDashboard } from "react-icons/md";

// export const DashBoardData: IDashboardSideBar[] = [
//   // {
//   //   title: "Dashboard",
//   //   path: "/",
//   //   icon: <MdSpaceDashboard />
//   // }
// ];