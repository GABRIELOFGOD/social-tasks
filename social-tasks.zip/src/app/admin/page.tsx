import DashboardContent from '@/components/features/admin/DashboardContent'
import React from 'react'

const Admin = () => {
  return <DashboardContent />
}

export default Admin