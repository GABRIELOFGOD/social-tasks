"use client";

import ConnectWalletModal from "@/components/common/modal/ConnectWalletModal";
import { IUser } from "@/model/userTypes";
import { createContext, useContext, useState } from "react";

interface IGlobalContext {
  user: IUser | null;
  setUser: (user: IUser) => void;
  openConnectModal: boolean;
  setOpenConnectModal: (open: boolean) => void;
}

const GlobalContext = createContext<IGlobalContext | null>(null);

export const GlobalProvider = ({ children }: {
  children: React.ReactNode;
}) => {
  const [user, setUser] = useState<IUser | null>(null);
  const [openConnectModal, setOpenConnectModal] = useState<boolean>(false);

  return (
    <GlobalContext.Provider value={{ user, setUser, openConnectModal, setOpenConnectModal }}>
      {children}
      {openConnectModal && <ConnectWalletModal closeModal={() => setOpenConnectModal(false)} />}
    </GlobalContext.Provider>
  );
};

export const useGlobalContext = () => {
  const context = useContext(GlobalContext);
  if (!context) {
    throw new Error('useGlobalContext must be used within a GlobalProvider');
  }
  return context;
};
