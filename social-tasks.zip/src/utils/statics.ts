export const instagram = "/socials/instagram.png";
export const facebook = "/socials/facebook.png";
export const telegram = "/socials/telegram.png";
export const x = "/socials/x.png";
export const tiktok = "/socials/tiktok.png";
export const discord = "/socials/discord.png";