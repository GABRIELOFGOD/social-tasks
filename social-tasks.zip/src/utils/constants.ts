export const Logo = "/logo.svg";
export const sub = "/sub.svg";

// export const BASEURL = "http://localhost:5000";
export const BASEURL = process.env.BASEURL;